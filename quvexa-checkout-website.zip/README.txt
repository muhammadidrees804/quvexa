QORVEXA / QUVEXA CHECKOUT FRONTEND PREVIEW

FILES
- index.html: checkout page
- styles.css: responsive styling
- script.js: quantity, billing toggle, demo form validation

GITHUB UPLOAD
Upload all three website files (index.html, styles.css, script.js) to the root of your quvexa repository, replacing the earlier preview files if prompted. Commit changes.

IMPORTANT SECURITY / LAUNCH NOTES
This is a frontend-only preview. It does not create orders, collect card details, or process payments.
Do not add raw card-number or CVV fields to this static page. Before accepting real orders:
1. Choose a payment processor that supports your business and country.
2. Implement its hosted checkout or secure tokenized payment elements with a backend.
3. Create server-side order validation and secure order storage.
4. Configure shipping rates, taxes, refund/return policy, privacy policy, terms, and customer support.
5. Test successful, declined, refunded, and abandoned payments before launch.

The displayed $44.99 is a placeholder launch price. Shipping and tax are not yet calculated.
