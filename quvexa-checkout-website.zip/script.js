document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("checkoutForm");
const sameBilling = document.getElementById("sameBilling");
const billingFields = document.getElementById("billingFields");
const qtyOutput = document.getElementById("quantity");
const thumbQty = document.querySelector(".qty");
const unitPrice = 44.99;
let quantity = 1;

function updateTotals() {
  qtyOutput.textContent = quantity;
  thumbQty.textContent = quantity;
  document.getElementById("subtotal").textContent = "$" + (unitPrice * quantity).toFixed(2);
  document.getElementById("total").textContent = "$" + (unitPrice * quantity).toFixed(2);
}
document.getElementById("minus").addEventListener("click", () => {
  quantity = Math.max(1, quantity - 1);
  updateTotals();
});
document.getElementById("plus").addEventListener("click", () => {
  quantity = Math.min(10, quantity + 1);
  updateTotals();
});

sameBilling.addEventListener("change", () => {
  billingFields.classList.toggle("hidden", sameBilling.checked);
  billingFields.querySelectorAll("input, select").forEach(field => {
    field.required = !sameBilling.checked && !field.name.endsWith("Address2");
  });
});

document.querySelectorAll('input[name="payment"]').forEach(radio => {
  radio.addEventListener("change", () => {
    document.querySelectorAll(".payment-choice").forEach(choice => choice.classList.remove("selected"));
    radio.closest(".payment-choice").classList.add("selected");
  });
});

form.addEventListener("submit", event => {
  event.preventDefault();
  const message = document.getElementById("formMessage");
  if (!form.reportValidity()) return;

  message.textContent = "Thank you! Your checkout details look complete in this preview. No order has been placed and no payment has been taken. Secure payment processing must be connected before QORVEXA can accept real orders.";
  message.classList.add("show");
  message.scrollIntoView({behavior: "smooth", block: "center"});
});
